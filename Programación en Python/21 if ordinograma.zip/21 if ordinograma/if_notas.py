'''if notas'''
# Este lo hice yo
# nota = int(input("Por favor, dime la nota que tienes:"))
# print(nota)
# if nota < 5:
#     print("Suspenso")
# if nota == 5:
#     print("Suficiente")
# if nota == 6:
#     print("Bien")
# if nota == 7:
#     print("Notable")
# elif nota == 8:
#     print("Notable")
# if nota == 9:
#     print("Sobresaliente")
# if nota == 10:
#     print("Matrícula de honor")
# if nota < 10:
#     print("No sirve como nota")
##############################################################

# Corrección
nota = float(input("Introduce la nota:"))
print(nota)
mensaje = "nada"
if nota > 10:
    mensaje = "Nota fuera de rango"
elif nota == 10:
    mensaje = "MH"
elif nota >= 9:
    mensaje = "Sobresaliente"
elif nota >= 7:
    mensaje = "Notable"
elif nota >= 6:
    mensaje = "Bien"
elif nota >= 5:
    mensaje = "Aprobado"
elif nota >= 0:
    mensaje = "Suspenso"
else:
    mensaje = "No es una nota"  # para numeros negativos
print(mensaje)
