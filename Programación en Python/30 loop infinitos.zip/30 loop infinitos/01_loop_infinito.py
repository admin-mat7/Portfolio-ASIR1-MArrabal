'''Loop Infinito'''
while True:
    mensaje = input("$ ")
    print("Has escrito", mensaje)
